<?php $__env->startSection('title', __('Events')); ?>
<section class="py-32">
	<div class="container-fluid">
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<div style="display: flex; justify-content: space-between; align-items: center;">
							<div class="float-left">
								<h4><i></i>
									Lista de Eventos </h4>
							</div>
							<?php if(session()->has('message')): ?>
							<div wire:poll.4s class="btn btn-sm btn-success" style="margin-top:0px; margin-bottom:0px;"> <?php echo e(session('message')); ?> </div>
							<?php endif; ?>
							<div>
								<input wire:model='keyWord' type="text" class="form-control" name="search" id="search" placeholder="Buscar Eventos">
							</div>
							<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>
							<div class="btn btn-sm btn-info" data-toggle="modal" data-target="#createDataModal">

								<i class="fa fa-plus"></i> Añadir Eventos

							</div>
							<?php endif; ?>
						</div>
					</div>

					<div class="card-body">
						<?php echo $__env->make('livewire.events.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo $__env->make('livewire.events.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="table-responsive">
							<table class="table table-bordered table-sm">
								<thead class="thead">
									<tr>
										<td>#</td>
										<th>Evento</th>
										<th>Descripción</th>
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>
										<th>Status</th>
										<td>Acciones</td>
										<?php endif; ?>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>

										<td><?php echo e($row->nomevento); ?></td>
										<td><?php echo e($row->descripcion); ?></td>
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>
										<td><?php echo e($row->status); ?></td>

										<td width="90">
											<div class="btn-group">
												<button type="button" class="btn btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													Actions
												</button>
												<div class="dropdown-menu dropdown-menu-right">
													<a data-toggle="modal" data-target="#updateModal" class="dropdown-item" wire:click="edit(<?php echo e($row->id); ?>)"><i class="fa fa-edit"></i> Editar </a>
													<a class="dropdown-item" onclick="confirm('Confirm Delete Event id <?php echo e($row->id); ?>? \nDeleted Events cannot be recovered!')||event.stopImmediatePropagation()" wire:click="destroy(<?php echo e($row->id); ?>)"><i class="fa fa-trash"></i> Eliminar </a>
												</div>
											</div>
										</td>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
							<?php echo e($events->links()); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</section><?php /**PATH C:\xampp\htdocs\schoolcamp\resources\views/livewire/events/view.blade.php ENDPATH**/ ?>