<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('registroalumnos')->html();
} elseif ($_instance->childHasBeenRendered('REfpa3P')) {
    $componentId = $_instance->getRenderedChildComponentId('REfpa3P');
    $componentTag = $_instance->getRenderedChildComponentTagName('REfpa3P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('REfpa3P');
} else {
    $response = \Livewire\Livewire::mount('registroalumnos');
    $html = $response->html();
    $_instance->logRenderedChild('REfpa3P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\schoolcamp\resources\views/livewire/registroalumnos/index.blade.php ENDPATH**/ ?>