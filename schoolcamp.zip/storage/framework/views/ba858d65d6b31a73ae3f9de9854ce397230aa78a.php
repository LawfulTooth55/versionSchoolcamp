
<?php $__env->startSection('corpus'); ?>
<header id="header">
				<a href="/dashboard" class="title">School Camp</a>
				<nav>
						<ul>
							<?php if(auth()->guard()->check()): ?>
								<li>
									<a href="<?php echo e(url('/tallers')); ?>"class="button"><i ></i> Talleres</a>
								</li>
							<?php endif; ?>

							<li class="nav-item">
                           	 <a href="<?php echo e(url('/users')); ?>" class="nav-link"><i class=""></i> Perfil</a> 
                        	</li>

							<li><a href="#three">Contacto</a></li>
							
                            <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
								<?php echo csrf_field(); ?>

								<a href="route('logout')"
										onclick="event.preventDefault();
										this.closest('form').submit();">
									<?php echo e(__('Cerrar Sesión')); ?>

								</a>
                        	</form>
                            </li>
						</ul>
					</nav>
			</header>
                <section id="three" class="wrapper style1 fade-up">
						<div class="inner">
							<h2>Inscripción talleres</h2>
							<p>Recuerda que como dijeron los de 343 inddustries "TODO GRAN VIAJE, COMIENZA CON UN PRIMER PASO"</p>
							<div class="split style1">
								<section>
									<form method="post" action="#">
										<div class="fields">
											<div class="field half">
												<label for="taller">Taller</label>
												<input type="text" name="taller" id="taller" />
											</div>
											<div class="field half">
												<label for="sede">Sede</label>
												<input type="text" name="sede" id="sede" />
											</div>
										</div>
										<ul class="actions">
											<li><a href="" class="button submit">inscribirse</a></li>
										</ul>
									</form>
								</section>
								<section>
									<img src="https://bucket.mlcdn.com/a/523/523809/images/3720a7f51416e33704e930d2060a3b34a6c5ab9e.png" width="500" alt="">
								</section>
							</div>
						</div>
					</section>
                    	<!-- Footer -->
			<footer id="footer" class="wrapper style1-alt">
				<div class="inner">
					<ul class="menu">
						<li>&copy; Todos los derechos reservados</li><li>Design: <a href="#">JD</a></li>
					</ul>
				</div>
			</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\schoolcamp\resources\views/formtaller.blade.php ENDPATH**/ ?>