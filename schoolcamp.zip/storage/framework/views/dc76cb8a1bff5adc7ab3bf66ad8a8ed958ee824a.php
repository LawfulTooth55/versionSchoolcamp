<?php $__env->startSection('title', __('Talleres')); ?>
<section class="py-32">
<div class="container-fluid">
	<div class="row justify-content-center">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<div style="display: flex; justify-content: space-between; align-items: center;">
						<div class="float-left">
							<h4><i></i>
								Talleres Activos </h4>
						</div>
						<?php if(session()->has('message')): ?>
						<div wire:poll.4s class="btn btn-sm btn-success" style="margin-top:0px; margin-bottom:0px;"> <?php echo e(session('message')); ?> </div>
						<?php endif; ?>
						<div>
							<input wire:model='keyWord' type="text" class="form-control" name="search" id="search" placeholder="Buscar Taller">
						</div>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>
						<div class="btn btn-sm btn-info" data-toggle="modal" data-target="#createDataModal">
							<i class="fa fa-plus"></i> Añadir Taller
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class="card-body">
					<?php echo $__env->make('livewire.tallers.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					<?php echo $__env->make('livewire.tallers.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="table-responsive">
						<table class="table table-bordered table-sm">
							<thead class="thead">
								<tr>
									<td>#</td>
									<th>Taller</th>
									<?php if(auth()->guard()->check()): ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>
									<th>Editar talleres</th>
									<?php else: ?>
									<th>Acciones</th>
									<?php endif; ?>
									<?php endif; ?>

								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $tallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($row->nomtaller); ?></td>
									<?php if(auth()->guard()->check()): ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>

									<?php else: ?>
									<td>
										<div class="btn-group">
											<button type="button" class="btn btn-sm  black-text"><a href="<?php echo e(url('/registroalumno/create')); ?>">
													Registrate
												</a>
											</button>
										</div>
									</td>
									<?php endif; ?>
									<?php endif; ?>



									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("EditarTalleres")): ?>
									<td width="90">
										<div class="btn-group">
											<button type="button" class="btn btn-sm dropdown-toggle black-text" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												Acciones
											</button>
											<div class="dropdown-menu dropdown-menu-right">
												<a data-toggle="modal" data-target="#updateModal" href="#updateModal" class="dropdown-item" wire:click="edit(<?php echo e($row->id); ?>)"><i class="fa fa-edit"></i> Editar </a>
												<a class="dropdown-item" onclick="confirm('Confirm Delete Taller id <?php echo e($row->id); ?>? \nDeleted Tallers cannot be recovered!')||event.stopImmediatePropagation()" wire:click="destroy(<?php echo e($row->id); ?>)"><i class="fa fa-trash"></i> Eliminar </a>
											</div>
										</div>
									</td>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
						<?php echo e($tallers->links()); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</section><?php /**PATH C:\xampp\htdocs\schoolcamp\resources\views/livewire/tallers/view.blade.php ENDPATH**/ ?>