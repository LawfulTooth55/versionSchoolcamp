
<?php $__env->startSection('corpus'); ?>
<?php echo \Livewire\Livewire::styles(); ?>

    <!-- Header -->
    <header id="header">
				<a href="/dashboard" class="title">School Camp</a>
				<nav>
					<ul>
						<li><a href="/dashboard">Inicio</a></li>
						<li><a href="#" class="active">Talleres</a></li>
                        <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Cerrar Sesión')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </form>
                        </li>
					</ul>
				</nav>
			</header>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<section id="main" class="wrapper">
						<div class="inner">
							<h1 class="major">Talleres</h1>
									<div class="table-wrapper">
										<table>
											<thead>
												<tr>
													<th>Nombre</th>
													<th>sede</th>
													<th>Cupo</th>
										
													<th>Acciones</th>
												</tr>
											</thead>
											<tbody>
												<?php $__currentLoopData = $vertalleres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($taller->taller); ?></td>
													<td><?php echo e($taller->sede); ?></td>
													<td><?php echo e($taller->cupo); ?></td>
													<td></td>
												</tr>
											</tbody>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</table>
									</div>
						</div>
					</section>
			</div>
            

		<!-- Footer -->
			<footer id="footer" class="wrapper alt">
				<div class="inner">
					<ul class="menu">
						<li>&copy; SchoolCamp. Todos los derechos reservados.</li><li>Design: <a href="#">JD</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\schoolcamp\resources\views/taller/index.blade.php ENDPATH**/ ?>