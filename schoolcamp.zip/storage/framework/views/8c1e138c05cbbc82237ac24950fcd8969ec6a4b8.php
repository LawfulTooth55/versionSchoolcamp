<?php $__env->startSection('content3'); ?>
<div>
    
   <h1>hola mundo</h1>
</div>
<?php echo $__env->make('layouts.appa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\schoolcamp\resources\views/livewire/perfil.blade.php ENDPATH**/ ?>