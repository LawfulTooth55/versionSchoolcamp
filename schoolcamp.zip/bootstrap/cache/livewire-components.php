<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'events' => 'App\\Http\\Livewire\\Events',
  'perfil' => 'App\\Http\\Livewire\\Perfil',
  'registroalumnos' => 'App\\Http\\Livewire\\Registroalumnos',
  'tallers' => 'App\\Http\\Livewire\\Tallers',
  'users' => 'App\\Http\\Livewire\\Users',
);